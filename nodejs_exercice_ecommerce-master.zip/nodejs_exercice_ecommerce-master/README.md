# Projet NodeJs avec la PRO10

Nous découvrons le framework **express** 

Nous testons en mettant du versionning avec *GIT*

## Installer le projet
> npm install

## Démarrer le projet
> npm start